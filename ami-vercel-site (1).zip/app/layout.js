import "./globals.css";

export const metadata = {
  title: "AMI Global Solutions LLC",
  description: "Delivery, hauling, yard work, and power washing in Houston and surrounding counties."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
