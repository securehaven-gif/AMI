export default function HomePage() {
  return (
    <main>
      <section className="hero">
        <div className="container center">
          <p className="eyebrow">AMI Global Solutions LLC</p>
          <h1>Fast. Reliable. Ready When You Are.</h1>
          <p className="subhead">Delivery • Hauling • Yard Work • Power Washing</p>
          <div className="buttonRow">
            <a className="button buttonOutline" href="tel:8442573783">Call 844-257-3783</a>
            <a className="button buttonSolid" href="#contact">Book a Job</a>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="sectionTitle center">Our Services</h2>
          <div className="grid3">
            <div className="card">
              <h3>Delivery &amp; Transport</h3>
              <p>Local delivery, hotshot loads, furniture &amp; appliance moves.</p>
            </div>
            <div className="card">
              <h3>Yard Services</h3>
              <p>Grass cutting, debris cleanup, light hauling.</p>
            </div>
            <div className="card">
              <h3>Power Washing</h3>
              <p>Driveways, sidewalks, and exterior cleaning.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section alt">
        <div className="container center narrow">
          <h2 className="sectionTitle">Request a Service</h2>
          <p className="sectionText">
            Submit your request and we&apos;ll get back to you quickly to confirm details and scheduling.
          </p>
          <a className="button buttonSolid" href="#contact">Submit Request</a>
        </div>
      </section>

      <section className="section">
        <div className="container center narrow">
          <h2 className="sectionTitle">Why Choose AMI Global Solutions LLC?</h2>
          <p className="sectionText">
            Serving Houston and surrounding counties. Fast response times. Reliable, professional service.
          </p>
        </div>
      </section>

      <section className="section alt">
        <div className="container center narrow">
          <h2 className="sectionTitle">Recent Work</h2>
          <p className="sectionText">
            Add before &amp; after photos here to showcase your results.
          </p>
        </div>
      </section>

      <section className="section dark" id="contact">
        <div className="container center narrow">
          <h2 className="sectionTitle light">Get a Quote Today</h2>
          <p className="contactLine"><strong>Call:</strong> 844-257-3783</p>
          <p className="contactLine">aston@amiglobalsolutions.com</p>
          <p className="contactLine">info@amiglobalsolutions.com</p>
        </div>
      </section>
    </main>
  );
}
